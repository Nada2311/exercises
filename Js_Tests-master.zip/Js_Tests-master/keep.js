"use strict";

/*
 * Create a function `keepFirst` takes a string
 * and only keep the 2 first characters
 *
 * Create a function `keepLast` takes a string
 * and only keep the 2 last characters
 *
 * Create a function `keepFirstLast` takes a string
 * and only keep 2 characters from the third character
 *
 * @next capitalize
 */

function keepFirst(arg) {
  var arr = arg.split("");
  arr.splice(2, arr.length - 2);
  arr.join("");
  console.log(arr);
}
keepFirst("string");

function keepLast(arg) {
  var arr = arg.split("");
  arr.splice(0, arr.length - 2);
  arr.join("");
  console.log(arr);
}
keepLast("string");

function keepFirstLast(arg) {
  var arr = arg.split("");

  console.log(arr[3], arr[4]);
}
keepFirstLast("string");
// You must write your own tests
throw Error("No tests !");
