"use strict";

/*
 * Create the function `cutFirst` that takes a string and remove the 2 last characters
 * Create the function `cutLast` that takes a string and remove the 2 first charcters
 * Create the function `cutFistLast` that takes a string
 * and remove the 2 first charcters and 2 last characters
 *
 * @next keep
 */

function cutFirst(string) {
  let arr = string.split("");
  let length = arr.length;
  arr.splice(length - 2, 2);
  let stringAgain = arr.join("");
  console.log(stringAgain);
}
cutFirst("string");

function cutLast(string) {
  let arr = string.split("");
  arr.splice(0, 2);
  let stringAgain = arr.join("");
  console.log(stringAgain);
}
cutLast("string");

function cutFistLast(string) {
  let arr = string.split("");
  arr.splice(0, 2);
  let length = arr.length;
  arr.splice(length - 2, 2);
  let stringAgain = arr.join("");
  console.log(stringAgain);
}
cutFistLast("string");

// You must write your own tests
throw Error("No tests !");
