"use strict";

/*
 * Jaden Smith Case
 *
 * Make a function `jadenCase` that takes a String
 * and return capitalize each words: "How are you ?" -> "How Are You ?"
 *
 * @next total
 */
function jadenCase(string) {
  document.querySelector("body").innerHTML = "<h1>" + string + "</h1>";
  document.querySelector("h1").style.textTransform = "capitalize";
  return string;
}
jadenCase("How are you ?");

// You must write your own tests
const assert = require("assert");

assert.strictEqual(typeof jadenCase, "function");
assert.strictEqual(jadenCase.length, 1);
assert.strictEqual(jadenCase("How are you ?"), "How Are You");
assert.strictEqual(jadenCase("what's your name?"), "What's Your Name?");
