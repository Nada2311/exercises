"use strict";

/*
 * Create a function `capitalize` takes a string
 * and transform to upper case only the first letter
 *
 * @next jaden-case
 */
function capitalize(string) {
  document.querySelector("body").innerHTML = "<h1>" + string + "</h1>";
  document.querySelector("h1").style.textTransform = "capitalize";
  return string;
}
capitalize("string");
// You must write your own tests
const assert = require("assert");

assert.strictEqual(typeof capitalize, "function");
assert.strictEqual(capitalize.length, 1);
assert.strictEqual(capitalize("string"), "String");
