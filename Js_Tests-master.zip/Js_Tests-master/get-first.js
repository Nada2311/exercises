"use strict";

/*
 * Create a `getFirst` function that takes an array or a string
 * and return the first element
 *
 * @notions Data-Structures, Get
 * @next get-last
 */

// Your code :
function getFirst(arg) {
  if (typeof arg == "string") {
    var arr = arg.split("");
  } else {
    arr = arg;
  }
  console.log(arr[0]);
}
getFirst([0, 10, 2, 5]);
//* Begin of tests
const assert = require("assert");

assert.strictEqual(getFirst([2, 42]), 2);
assert.strictEqual(getFirst(["pouet", 4, true]), "pouet");
assert.strictEqual(getFirst([getFirst]), getFirst);
assert.strictEqual(getFirst("salut"), "s");
assert.strictEqual(getFirst([]), undefined);
// End of tests */
